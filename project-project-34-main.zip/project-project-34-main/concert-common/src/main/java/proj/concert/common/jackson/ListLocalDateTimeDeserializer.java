package proj.concert.common.jackson;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class ListLocalDateTimeDeserializer extends StdDeserializer<List<LocalDateTime>> {

    private static DateTimeFormatter FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    public ListLocalDateTimeDeserializer() {
        this(null);
    }

    public ListLocalDateTimeDeserializer(Class<LocalDateTime> clazz) {
        super(clazz);
    }

    @Override
    public List<LocalDateTime> deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
        List<LocalDateTime> dates = new ArrayList<>();
        JsonToken token = jsonParser.getCurrentToken();

        if (token == JsonToken.START_ARRAY) {
            while ((token = jsonParser.nextToken()) != JsonToken.END_ARRAY) {
                String dateStr = jsonParser.getText();
                if (dateStr == null || dateStr.isEmpty()) {
                    dates.add(null);
                } else {
                    try {
                        LocalDateTime date = LocalDateTime.parse(dateStr, FORMATTER);
                        dates.add(date);
                    } catch (DateTimeParseException e) {
                        throw new IllegalArgumentException("Failed to parse date", e);
                    }
                }
            }
        }

        return dates;
    }
}

