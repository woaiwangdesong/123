package proj.concert.common.types;

/**
 * Enumerated type for classifying performers.
 *
 */
public enum Genre {Pop, HipHop, RhythmAndBlues, Acappella, Metal, Rock, SoftRock, Theatre}