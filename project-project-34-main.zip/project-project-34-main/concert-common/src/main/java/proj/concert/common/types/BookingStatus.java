package proj.concert.common.types;

public enum BookingStatus {
    Booked, Unbooked, Any
}
