package proj.concert.service.services;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import proj.concert.common.dto.BookingRequestDTO;
import proj.concert.common.dto.ConcertInfoSubscriptionDTO;
import proj.concert.common.dto.UserDTO;
import proj.concert.common.types.BookingStatus;
import proj.concert.service.domain.*;
import proj.concert.service.jaxrs.LocalDateTimeParam;
import proj.concert.service.mapper.ConcertMapperConvert;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Path("/concert-service")
@Produces(MediaType.APPLICATION_JSON)
public class ConcertResource {

    private static Logger LOGGER = LoggerFactory.getLogger(ConcertResource.class);

    private static final int TOTAL_SEATS = 120;

    /**
     * Query concert information based on the ID.
     *
     * @param id
     * @return ConcertDTO
     */
    @GET
    @Path("/concerts/{id}")
    public Response getSingleConcert(@PathParam(value = "id") Long id) {
        EntityManager em = PersistenceManager.instance().createEntityManager();

        try {
            Concert concert = em.find(Concert.class, id);

            if (concert == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }

            return Response.status(Response.Status.OK)
                    .entity(ConcertMapperConvert.toConcertDTO(concert))
                    .build();
        } finally {
            if (em != null) {
                em.close();
            }
        }

    }

    /**
     * Query all concert information.
     *
     * @return List<ConcertDTO>
     */
    @GET
    @Path("/concerts")
    public Response getAllConcerts() {

        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {

            TypedQuery<Concert> query = em.createQuery("select c from Concert c", Concert.class);

            List<Concert> result = query.getResultList();

            return Response.status(Response.Status.OK)
                    .entity(ConcertMapperConvert.toListConcertDTO(result))
                    .build();
        } finally {
            if (em != null) {
                em.close();
            }
        }


    }


    /**
     * Get summary information.
     *
     * @return List<ConcertSummaryDTO>
     */
    @GET
    @Path("/concerts/summaries")
    public Response getConcertSummaries() {

        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            TypedQuery<Concert> query = em.createQuery("select c from Concert c", Concert.class);

            List<Concert> result = query.getResultList();

            return Response.status(Response.Status.OK)
                    .entity(ConcertMapperConvert.toListConcertSummaryDTO(result))
                    .build();

        } finally {
            if (em != null) {
                em.close();
            }
        }
    }


    /**
     * Query performer information based on the performer id.
     *
     * @param id
     * @return List<PerformerDTO>
     */
    @GET
    @Path("/performers/{id}")
    public Response getGetSinglePerformer(@PathParam(value = "id") Long id) {

        EntityManager em = PersistenceManager.instance().createEntityManager();

        try {
            Performer performer = em.find(Performer.class, id);

            if (performer == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }

            return Response.status(Response.Status.OK)
                    .entity(ConcertMapperConvert.toPerformerDTO(performer))
                    .build();

        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    /**
     * Query all performers.
     *
     * @return List<PerformerDTO>
     */
    @GET
    @Path("/performers/")
    public Response getAllPerformers() {

        EntityManager em = PersistenceManager.instance().createEntityManager();

        try {
            TypedQuery<Performer> query = em.createQuery("select p from Performer p", Performer.class);

            List<Performer> result = query.getResultList();

            return Response.status(Response.Status.OK)
                    .entity(ConcertMapperConvert.toListPerformerDTO(result))
                    .build();

        } finally {
            if (em != null) {
                em.close();
            }
        }

    }


    /**
     * login
     *
     * @param userDTO
     * @return Response
     */
    @POST
    @Path("/login")
    public Response login(UserDTO userDTO) {

        EntityManager em = PersistenceManager.instance().createEntityManager();

        try {
            TypedQuery<User> query = em.createQuery("select u from User u where u.userName = ?1 and u.passWord = ?2", User.class)
                    .setParameter(1, userDTO.getUsername())
                    .setParameter(2, userDTO.getPassword());

            List<User> result = query.getResultList();


            if (result == null || result.size() == 0) {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }

            User user = result.get(0);

            return Response.ok()
                    .cookie(new NewCookie("auth", user.getUserName()))
                    .build();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }


    /**
     * Book a seat.
     *
     * @param req
     * @return List<BookingDTO>
     */
    @POST
    @Path("/bookings")
    public Response makeBooking(BookingRequestDTO req, @CookieParam("auth") String auth) {

        if (StringUtils.isBlank(auth)) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }

        EntityManager em = PersistenceManager.instance().createEntityManager();
        em.getTransaction().begin();
        try {
            TypedQuery<User> userQuery = em.createQuery("select u from User u where u.userName = :userName", User.class)
                    .setParameter("userName", auth);
            List<User> userResult = userQuery.getResultList();

            if (userResult == null || userResult.size() == 0) {
                throw new NotFoundException("User not found.");
            }

            User user = userResult.get(0);

            Concert concert = em.find(Concert.class, req.getConcertId());
            if (concert == null) {
                throw new NotFoundException("Concert not found.");
            }

            Optional<LocalDateTime> hasDate = concert.getDates()
                    .stream()
                    .filter(x -> x.isEqual(req.getDate()))
                    .findAny();

            if (hasDate.isEmpty()) {
                throw new NotFoundException("No such date for the concert.");
            }

            // Pessimistic lock
            TypedQuery<Seat> currentSet = em.createQuery("select s from Seat s where s.date = :date and s.label in :labels and s.isBooked = false", Seat.class)
                    .setParameter("date", req.getDate())
                    .setParameter("labels", req.getSeatLabels())
                    .setLockMode(LockModeType.PESSIMISTIC_WRITE);

            List<Seat> result = currentSet.getResultList();
            if (result.size() != req.getSeatLabels().size()) {
                throw new BadRequestException("Not enough available seats.");
            }

            for (Seat seat : result) {
                seat.setBooked(true);
            }
            // booking
            Booking booking = new Booking(user, result, concert);
            // save
            em.persist(booking);

            em.getTransaction().commit();

            return Response.created(URI.create("/concert-service/bookings/" + booking.getId())).build();
        } catch (NotFoundException e) {
            em.getTransaction().rollback();
            return Response.status(Response.Status.BAD_REQUEST).build();
        } catch (BadRequestException e) {
            em.getTransaction().rollback();
            return Response.status(Response.Status.FORBIDDEN).entity(e.getMessage()).build();
        } catch (Exception e) {
            em.getTransaction().rollback();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        } finally {
            em.close();
        }

    }


    /**
     * Query subscription information based on the subscription id
     *
     * @param auth
     * @return BookingDTO
     */
    @GET
    @Path("/bookings/{bookingId}")
    public Response getOwnBookingById(@CookieParam("auth") String auth, @PathParam("bookingId") Long bookingId) {
        if (StringUtils.isBlank(auth)) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        EntityManager em = PersistenceManager.instance().createEntityManager();

        try {
            Booking booking = em.find(Booking.class, bookingId);

            em.close();

            if (!booking.getUser().getUserName().equals(auth)) {
                return Response.status(Response.Status.FORBIDDEN).build();
            }

            return Response.ok(ConcertMapperConvert.toBookingDTO(booking))
                    .build();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }


    /**
     * Get information about the seats that one has subscribed to
     *
     * @param auth
     * @return
     */
    @GET
    @Path("/bookings")
    public Response getOwnBookingById(@CookieParam("auth") String auth) {

        if (StringUtils.isBlank(auth)) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        EntityManager em = PersistenceManager.instance().createEntityManager();

        try {
            TypedQuery<User> userQuery = em.createQuery("SELECT u FROM User u WHERE u.userName = :userName", User.class)
                    .setParameter("userName", auth);

            List<User> users = userQuery.getResultList();
            if (users.isEmpty()) {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }

            User user = users.get(0);

            TypedQuery<Booking> bookingQuery = em.createQuery("SELECT b FROM Booking b WHERE b.user = :user", Booking.class)
                    .setParameter("user", user);

            return Response.ok(ConcertMapperConvert.toListBookingDTO(bookingQuery.getResultList()))
                    .build();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }


    /**
     * Query the seats that have been booked for the current date.
     *
     * @param date   @see proj.concert.service.jaxrs.LocalDateTimeParam
     * @param status
     * @return List<SeatDTO>
     */
    @GET
    @Path("/seats/{date}")
    public Response makeBooking(@PathParam("date") LocalDateTimeParam date, @QueryParam("status") BookingStatus status) {

        EntityManager em = PersistenceManager.instance().createEntityManager();

        try {
            String sql = "select s from Seat s where date = ?1 and isBooked in ?2";
            if (BookingStatus.Any == status) {
                sql = "select s from Seat s where date = ?1 ";
            }

            TypedQuery<Seat> query = em.createQuery(sql, Seat.class)
                    .setParameter(1, date.getLocalDateTime());

            if (BookingStatus.Any != status) {
                query.setParameter(2, status.ordinal() == 0);
            }

            List<Seat> result = query.getResultList();

            return Response.status(Response.Status.OK)
                    .entity(ConcertMapperConvert.toListSeatDTO(result))
                    .build();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    /**
     * subscribeConcertInfo
     *
     * @param req
     * @param auth
     * @return ConcertInfoNotificationDTO
     */
    @POST
    @Path("/subscribe/concertInfo")
    public Response subscribeConcertInfo(ConcertInfoSubscriptionDTO req, @CookieParam("auth") String auth) {
        if (StringUtils.isBlank(auth)) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            Concert concert = em.find(Concert.class, req.getConcertId());
            if (concert == null) {
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
            Optional<LocalDateTime> hasDate = concert.getDates()
                    .stream()
                    .filter(x -> x.isEqual(req.getDate()))
                    .findAny();

            if (hasDate.isEmpty()) {
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
            // loop select ! Simulated subscription.
            for (int i = 0; i < 10; i++) {
                TypedQuery<Long> alreadyCount = em.createQuery("select count(1) from Booking b join b.seats s  where b.concert.id = ?1 and s.date = ?2", Long.class)
                        .setParameter(1, req.getConcertId())
                        .setParameter(2, req.getDate());
                int count = alreadyCount.getSingleResult().intValue();

                if (count > req.getPercentageBooked()) {
                    return Response.ok(ConcertMapperConvert.toConcertInfoNotificationDTO((TOTAL_SEATS - count))).build();
                }
                // sleep 1 second again select
                Thread.sleep(1000);

            }
        } catch (Exception e) {
            // ignore
            return Response.serverError().build();
        } finally {
            if (em != null) {
                em.close();
            }
        }

        return Response.noContent().build();
    }


}
