package proj.concert.service.mapper;

import proj.concert.common.dto.*;
import proj.concert.service.domain.Booking;
import proj.concert.service.domain.Concert;
import proj.concert.service.domain.Performer;
import proj.concert.service.domain.Seat;

import java.util.ArrayList;
import java.util.List;

public class ConcertMapperConvert {

    public static ConcertDTO toConcertDTO(Concert concert) {
        if (concert == null) return null;

        ConcertDTO result = new ConcertDTO(
                concert.getId(),
                concert.getTitle(),
                concert.getImageName(),
                concert.getBlurb()
        );
        result.setDates(new ArrayList<>(concert.getDates()));

        result.setPerformers(toListPerformerDTO(concert.getPerformers()));

        return result;
    }


    public static List<ConcertDTO> toListConcertDTO(List<Concert> concerts) {
        List<ConcertDTO> result = new ArrayList<>();

        if (concerts == null || concerts.size() == 0) {
            return result;
        }

        for (Concert concert : concerts) {
            result.add(toConcertDTO(concert));
        }
        return result;
    }


    public static List<ConcertSummaryDTO> toListConcertSummaryDTO(List<Concert> concerts) {
        List<ConcertSummaryDTO> result = new ArrayList<>();

        if (concerts == null || concerts.size() == 0) {
            return result;
        }

        for (Concert concert : concerts) {
            result.add(toConcertSummaryDTO(concert));
        }
        return result;
    }

    public static ConcertSummaryDTO toConcertSummaryDTO(Concert concert) {
        if (concert == null) return null;

        return new ConcertSummaryDTO(
                concert.getId(),
                concert.getTitle(),
                concert.getImageName()
        );
    }


    public static PerformerDTO toPerformerDTO(Performer performer) {
        if (performer == null) return null;

        return new PerformerDTO(
                performer.getId(),
                performer.getName(),
                performer.getImageName(),
                performer.getGenre(),
                performer.getBlurb()
        );
    }


    public static List<PerformerDTO> toListPerformerDTO(List<Performer> performers) {
        List<PerformerDTO> result = new ArrayList<>();
        if (performers == null || performers.size() == 0) {
            return result;
        }

        for (Performer performer : performers) {
            result.add(toPerformerDTO(performer));
        }
        return result;
    }


    public static SeatDTO toSeatDTO(Seat seat) {
        if (seat == null) {
            return null;
        }
        return new SeatDTO(seat.getLabel(), seat.getCost());
    }


    public static List<SeatDTO> toListSeatDTO(List<Seat> seats) {
        List<SeatDTO> result = new ArrayList<>();
        if (seats == null || seats.size() == 0) {
            return result;
        }
        for (Seat seat : seats) {
            result.add(toSeatDTO(seat));
        }
        return result;
    }

    public static BookingDTO toBookingDTO(Booking booking) {
        Concert concert = booking.getConcert();
        List<Seat> seats = booking.getSeats();
        return new BookingDTO(concert.getId(),
                seats.get(0).getDate(),
                toListSeatDTO(seats)
        );
    }

    public static List<BookingDTO> toListBookingDTO(List<Booking> bookings) {
        List<BookingDTO> result = new ArrayList<>();

        if (bookings == null || bookings.size() == 0) {
            return result;
        }
        for (Booking booking : bookings) {
            result.add(toBookingDTO(booking));

        }
        return result;
    }

    public static ConcertInfoNotificationDTO toConcertInfoNotificationDTO(Integer numSeatsRemaining) {
        return new ConcertInfoNotificationDTO(numSeatsRemaining);
    }
}
